#ifndef __REQUEST_H__
#define __REQUEST_H__
#include "thread_data.h"

void requestHandle(int fd, ThreadData statistics);

#endif
